package com.fisiaewiso

data class OptionWithImage(val text: String, val imageResId: Int)