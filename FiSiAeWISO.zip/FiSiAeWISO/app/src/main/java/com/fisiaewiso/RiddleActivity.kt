package com.fisiaewiso

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.Log
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.children
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Collections
import kotlin.properties.Delegates
import kotlin.text.toDoubleOrNull

class RiddleActivity : AppCompatActivity() {

    private lateinit var currentRiddle: Riddle
    private lateinit var tVRiddle_Initialize: TextView
    private lateinit var tVRiddle_Initialize2: TextView
    private lateinit var riddleTextView: TextView
    private lateinit var imageView: View
    private lateinit var numberInput: EditText
    private lateinit var numberInput2: EditText
    private lateinit var dateInput: EditText
    private lateinit var nextButton: Button
    private lateinit var previousButton: Button
    private lateinit var startButton: Button
    private var currentRiddleIndex = 0
    private lateinit var riddles: List<Riddle>
    private val selectedAnswersOrder = mutableListOf<String>()
    private lateinit var radioGroupAnswers: RadioGroup
    private val checkBoxes = mutableListOf<CheckBox>()
    private lateinit var linearLayoutAnswers: LinearLayout
    private lateinit var linearLayoutSpinners: LinearLayout
    private lateinit var linearLayoutRecyclerView: ConstraintLayout
    private lateinit var optionsRecyclerView: androidx.recyclerview.widget.RecyclerView
    private lateinit var targetLinearLayout: LinearLayout
    private lateinit var linearTextView: LinearLayout
    private lateinit var target1TextView: TextView
    private lateinit var target2TextView: TextView
    private lateinit var target3TextView: TextView
    private lateinit var target4TextView: TextView
    private lateinit var target5TextView: TextView
    private val radioButtons = mutableListOf<RadioButton>()
    private val answerTextViews = mutableListOf<TextView>()
    private lateinit var tVcorrectRiddle1: TextView
    private lateinit var tVcorrectRiddle2: TextView
    private lateinit var tVcorrectRiddle3: TextView
    private lateinit var tVcorrectRiddle4: TextView
    private lateinit var tVcorrectRiddle5: TextView
    private lateinit var tVcorrectRiddle6: TextView
    private lateinit var tVcorrectRiddle7: TextView
    private lateinit var tVcorrectRiddle8: TextView
    private lateinit var tVcorrectRiddle9: TextView
    private lateinit var tVcorrectRiddle10: TextView
    private lateinit var tVcorrectRiddle11: TextView
    private lateinit var tVcorrectRiddle12: TextView
    private lateinit var tVcorrectRiddle13: TextView
    private lateinit var tVcorrectRiddle14: TextView
    private lateinit var tVcorrectRiddle15: TextView
    private lateinit var tVcorrectRiddle16: TextView
    private lateinit var tVcorrectRiddle17: TextView
    private lateinit var tVcorrectRiddle18: TextView
    private lateinit var tVcorrectRiddle19: TextView
    private lateinit var tVcorrectRiddle20: TextView
    private lateinit var tVcorrectRiddle21: TextView
    private lateinit var tVcorrectRiddle22: TextView
    private lateinit var tVcorrectRiddle23: TextView
    private lateinit var tVcorrectRiddle24: TextView
    private lateinit var tVcorrectRiddle25: TextView
    private lateinit var tVcorrectRiddle26: TextView
    private lateinit var tVcorrectRiddle27: TextView
    private lateinit var tVcorrectRiddle28: TextView
    private lateinit var tVcorrectRiddle29: TextView
    private lateinit var tVcorrectRiddle30: TextView
    private lateinit var unit1TextView: TextView
    private lateinit var unit2TextView: TextView
    private lateinit var unitDateTextView: TextView
    private lateinit var currentIntro: String
    private var riddlesLoaded = false
    private var totalPoints = 0.0
    private lateinit var viewModel: RiddleViewModel
    private var riddleMainNumber: Int by Delegates.notNull()
    private var userMappings = mutableMapOf<String, String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_riddle)
        tVRiddle_Initialize = findViewById(R.id.riddle_initialize)
        tVRiddle_Initialize2 = findViewById(R.id.riddle_initialize2)
        riddleTextView = findViewById(R.id.textView3)
        imageView = findViewById<ImageView>(R.id.riddle_image)
        tVcorrectRiddle1 = findViewById(R.id.tVcorrectRiddle1)
        tVcorrectRiddle2 = findViewById(R.id.tVcorrectRiddle2)
        tVcorrectRiddle3 = findViewById(R.id.tVcorrectRiddle3)
        tVcorrectRiddle4 = findViewById(R.id.tVcorrectRiddle4)
        tVcorrectRiddle5 = findViewById(R.id.tVcorrectRiddle5)
        tVcorrectRiddle6 = findViewById(R.id.tVcorrectRiddle6)
        tVcorrectRiddle7 = findViewById(R.id.tVcorrectRiddle7)
        tVcorrectRiddle8 = findViewById(R.id.tVcorrectRiddle8)
        tVcorrectRiddle9 = findViewById(R.id.tVcorrectRiddle9)
        tVcorrectRiddle10 = findViewById(R.id.tVcorrectRiddle10)
        tVcorrectRiddle11 = findViewById(R.id.tVcorrectRiddle11)
        tVcorrectRiddle12 = findViewById(R.id.tVcorrectRiddle12)
        tVcorrectRiddle13 = findViewById(R.id.tVcorrectRiddle13)
        tVcorrectRiddle14 = findViewById(R.id.tVcorrectRiddle14)
        tVcorrectRiddle15 = findViewById(R.id.tVcorrectRiddle15)
        tVcorrectRiddle16 = findViewById(R.id.tVcorrectRiddle16)
        tVcorrectRiddle17 = findViewById(R.id.tVcorrectRiddle17)
        tVcorrectRiddle18 = findViewById(R.id.tVcorrectRiddle18)
        tVcorrectRiddle19 = findViewById(R.id.tVcorrectRiddle19)
        tVcorrectRiddle20 = findViewById(R.id.tVcorrectRiddle20)
        tVcorrectRiddle21 = findViewById(R.id.tVcorrectRiddle21)
        tVcorrectRiddle22 = findViewById(R.id.tVcorrectRiddle22)
        tVcorrectRiddle23 = findViewById(R.id.tVcorrectRiddle23)
        tVcorrectRiddle24 = findViewById(R.id.tVcorrectRiddle24)
        tVcorrectRiddle25 = findViewById(R.id.tVcorrectRiddle25)
        tVcorrectRiddle26 = findViewById(R.id.tVcorrectRiddle26)
        tVcorrectRiddle27 = findViewById(R.id.tVcorrectRiddle27)
        tVcorrectRiddle28 = findViewById(R.id.tVcorrectRiddle28)
        tVcorrectRiddle29 = findViewById(R.id.tVcorrectRiddle29)
        tVcorrectRiddle30 = findViewById(R.id.tVcorrectRiddle30)
        unit1TextView = findViewById(R.id.unit1TextView)
        unit2TextView = findViewById(R.id.unit2TextView)
        unitDateTextView = findViewById(R.id.unitDateTextView)
        target1TextView = findViewById(R.id.target1TextView)
        target2TextView = findViewById(R.id.target2TextView)
        target3TextView = findViewById(R.id.target3TextView)
        target4TextView = findViewById(R.id.target4TextView)
        target5TextView = findViewById(R.id.target5TextView)
        radioGroupAnswers = findViewById(R.id.rGRiddleAnswer)
        linearLayoutAnswers = findViewById(R.id.linearLayoutAnswers)
        linearLayoutSpinners = findViewById(R.id.linearLayoutSpinners)
        linearLayoutRecyclerView = findViewById(R.id.linearLayoutRecyclerView)
        optionsRecyclerView = findViewById(R.id.optionsRecyclerView)
        targetLinearLayout = findViewById(R.id.targetLinearLayout)
        linearTextView = findViewById(R.id.linearTextView)
        val repository = ResultRepository(AppDatabase.getDatabase(this).resultDao(), AppDatabase.getDatabase(this).riddleDao())
        viewModel = ViewModelProvider(this, RiddleViewModelFactory(repository)).get(RiddleViewModel::class.java)
        numberInput = findViewById(R.id.riddleResultNumber1)
        numberInput2 = findViewById(R.id.riddleResultNumber2)
        dateInput = findViewById(R.id.riddleResultDate)
        nextButton = findViewById(R.id.bRiddleNext)
        previousButton = findViewById(R.id.bRiddlePrevious)
        startButton = findViewById(R.id.startButton)
        currentRiddle = Riddle(0,0, 0,"Datenbank wird beim nächsten Neustart zur Verfügung stehen", listOf(), listOf(), listOf(),false, false, false, false, false, false, false,false, listOf(), listOf(), listOf(), mapOf())
        tVRiddle_Initialize.text = currentRiddle.question
        val introTexts = listOf(
            getString(R.string.Riddle1),
            getString(R.string.Riddle2),
            getString(R.string.Riddle3),
            getString(R.string.Riddle4)
        )
        currentIntro = ""
        currentIntro = introTexts.random()
        tVRiddle_Initialize2.text = currentIntro
        for (i in 1..30) {
            val textViewId = resources.getIdentifier("tVcorrectRiddle$i", "id", packageName)
            val textView = findViewById<TextView>(textViewId)
            answerTextViews.add(textView)
        }
        previousButton.text = "Schließen"
        startButton.setOnClickListener {
            loadRiddlesByIntro(currentIntro)
            currentIntro = ""
            riddlesLoaded = true
            tVRiddle_Initialize.visibility = View.GONE
            tVRiddle_Initialize2.visibility = View.GONE
            startButton.visibility = View.GONE
            nextButton.visibility = View.VISIBLE
            nextButton.isEnabled = false
            Handler(Looper.getMainLooper()).postDelayed({
                nextButton.isEnabled = true
            },2000) // 2 Sekunden Verzögerung
        }
        nextButton.setOnClickListener {
            if (currentRiddle.requiresNumberInput || currentRiddle.requiresTwoNumberInputs || currentRiddle.requiresDateInput || currentRiddle.requiresTimeInput) {
                // InputMethodManager abrufen
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                // Tastatur ausblenden
                imm.hideSoftInputFromWindow(numberInput.windowToken, 0)
                imm.hideSoftInputFromWindow(numberInput2.windowToken, 0)
                imm.hideSoftInputFromWindow(dateInput.windowToken, 0)
            }
            if (riddlesLoaded) {
                evaluateAnswer()
            }
        }

        previousButton.setOnClickListener {
            finish()
        }

    }

    private fun proceedToNextRiddle() {
        //showNextRiddle() // Nächste Frage laden
        nextButton.isEnabled = false
        Handler(Looper.getMainLooper()).postDelayed({
            nextButton.isEnabled = true
        },2000) // 2 Sekunden Verzögerung
    }

    private fun loadRiddlesByIntro(intro: String) {
        riddleMainNumber = when (intro) {
            getString(R.string.Riddle1) -> 1
            getString(R.string.Riddle2) -> 2
            getString(R.string.Riddle3) -> 3
            getString(R.string.Riddle4) -> 4
            else -> return // Oder eine andere Fehlerbehandlung
        }
        lifecycleScope.launch {
            initializeDatabase()
            loadRiddles(riddleMainNumber) {
                // currentRiddle im ViewModel aktualisieren, nachdem die Rätsel geladen wurden
                viewModel.updateCurrentRiddle(currentRiddle)
            }
        }
        // currentRiddle im ViewModel aktualisieren
        viewModel.updateCurrentRiddle(currentRiddle)
    }

    private fun showNextRiddle() {
        if (currentRiddleIndex < riddles.size) { // Überprüfe, ob noch Rätsel vorhanden sind
            currentRiddleIndex++ // Index für das nächste Rätsel aktualisieren
            if (currentRiddleIndex < riddles.size) { // Überprüfe erneut, ob noch Rätsel vorhanden sind
                currentRiddle = riddles[currentRiddleIndex]
                selectedAnswersOrder.clear()
                displayRiddle()
            } else {
                // Alle Rätsel wurden angezeigt
                showTotalPointsAndSaveResults()
            }
        } else {
            // Alle Rätsel wurden angezeigt
            showTotalPointsAndSaveResults()
        }
    }

    private suspend fun initializeDatabase() {
        withContext(Dispatchers.IO) {
            AppDatabase.getDatabase(this@RiddleActivity)
        }
    }

    private fun loadRiddles(riddleMainNumber: Int, onRiddlesLoaded: () -> Unit) {
        lifecycleScope.launch {
            riddles = AppDatabase.getDatabase(this@RiddleActivity).riddleDao().getRiddlesByNumber(riddleMainNumber).first() // Initialisiere riddles hier
            riddles = riddles.map { riddle ->
                riddle.copy(
                    question = riddle.question.replace(";", ","),
                    answers = riddle.answers.map { it.replace(";", ",") },
                    correctAnswers = riddle.correctAnswers.map { it.replace(";", ",") }
                )
            }
            if (riddles.isNotEmpty()) {
                currentRiddleIndex = 0
                currentRiddle = riddles[currentRiddleIndex]
                withContext(Dispatchers.Main) {
                    displayRiddle()
                    onRiddlesLoaded()
                }
            }
        }
    }

    private fun displayRiddle() {
        radioGroupAnswers.removeAllViews()
        radioButtons.clear()
        linearLayoutAnswers.removeAllViews() // Remove previous CheckBoxes
        checkBoxes.clear() // Clear the list for the new riddle
        userMappings.clear()
        val imageView: ImageView = findViewById(R.id.riddle_image)
        // Bild laden, falls vorhanden
        when (currentRiddle.riddleNumber) {
            21, 54, 65, 81, 112 -> { // Nur für Fragen mit Bildern
                val imageResource = when (currentRiddle.riddleNumber) {
                    21 -> R.drawable.mehrliniensystem
                    54 -> R.drawable.riddle2unterschriften
                    65 -> R.drawable.riddle65holiday
                    81 -> R.drawable.matrixsystem
                    112 -> R.drawable.gleichgewichtspreis
                    else -> 0 // Sollte nicht erreicht werden, aber zur Sicherheit
                }
                if (imageResource != 0) {
                    imageView.setImageResource(imageResource)
                    imageView.visibility = View.VISIBLE
                } else {
                    imageView.visibility = View.GONE
                }
            }
            else -> imageView.visibility = View.GONE // Bild ausblenden, falls keine Bildressource für die Frage vorhanden ist
        }
        val shouldShuffle = when (currentRiddle.riddleNumber) {
            2 -> true // Fragen, die geshuffelt werden sollen
            11 -> false // Frage, die nicht geshuffelt werden soll
            else -> true // Standardmäßig shufflen
        }
        val answersshuffle = if (shouldShuffle) {
            currentRiddle.answers.shuffled()
        } else {
            currentRiddle.answers // Originalreihenfolge beibehalten
        }
        if (shouldShuffle) {
            Collections.shuffle(answersshuffle) // answersshuffle direkt mischen
        }
        if (currentRiddle.requiresOrderedAnswers) {
            linearLayoutSpinners.removeAllViews()
            linearLayoutSpinners.visibility = View.VISIBLE
            linearLayoutRecyclerView.visibility = View.GONE
            val numSpinners = currentRiddle.correctAnswers.size
            for (i in 0 until numSpinners) {
                val spinner = Spinner(this)
                // Separate Liste von Antworten für jeden Spinner erstellen
                val spinnerAnswers = answersshuffle
                val adapter = MultilineSpinnerAdapter(this, R.layout.spinner_item_multiline, spinnerAnswers)
                spinner.adapter = adapter
                linearLayoutSpinners.addView(spinner)
            }
            checkBoxes.forEach { it.visibility = View.GONE }
            radioGroupAnswers.visibility = View.GONE
            dateInput.visibility = View.GONE
            unit1TextView.visibility = View.GONE
            unit2TextView.visibility = View.GONE
            unitDateTextView.visibility = View.GONE
        } else if (currentRiddle.requiresDragAndDrop) {
            unit1TextView.visibility = View.GONE
            unit2TextView.visibility = View.GONE
            unitDateTextView.visibility = View.GONE
            linearLayoutRecyclerView.visibility = View.VISIBLE
            val optionsAdapter = if (currentRiddle.optionsWithImage.isNotEmpty()) { // Bedingung für Bilder prüfen
                OptionsAdapter(currentRiddle.optionsWithImage.toMutableList()) // optionsWithImage direkt verwenden
            } else {
                OptionsAdapter(currentRiddle.options.toMutableList()) // options als Datenquelle verwenden, wenn keine Bilder vorhanden sind
            }
            optionsRecyclerView.adapter = optionsAdapter
            if(currentRiddle.optionsWithImage.isNotEmpty()){
                optionsRecyclerView.layoutManager = GridLayoutManager(this, 3) // 2 Spalten
            } else {
                optionsRecyclerView.layoutManager = LinearLayoutManager(this) // LayoutManager hinzufügen
            }
            // Ziele anzeigen
            val target1: FrameLayout = findViewById(R.id.target1)
            val target2: FrameLayout = findViewById(R.id.target2)
            val target3: FrameLayout = findViewById(R.id.target3)
            val target4: FrameLayout = findViewById(R.id.target4)
            val target5: FrameLayout = findViewById(R.id.target5)

            target1.removeAllViews()
            target2.removeAllViews()
            target3.removeAllViews()
            target4.removeAllViews()
            target5.removeAllViews()

            target1.addView(TextView(this).apply { text = "\n\n" })
            target2.addView(TextView(this).apply { text = "\n\n" })
            target3.addView(TextView(this).apply { text = "\n\n" })
            target4.addView(TextView(this).apply { text = "\n\n" })
            target5.addView(TextView(this).apply { text = "\n\n" })
            target1TextView.text = currentRiddle.targets[0]
            if(currentRiddle.targets.size > 1){
                target2TextView.text = currentRiddle.targets[1]
            }
            if (currentRiddle.targets.size > 2) {
                target3TextView.text = currentRiddle.targets[2]
            }
            if (currentRiddle.targets.size > 3) {
                target4TextView.text = currentRiddle.targets[3]
            }
            if (currentRiddle.targets.size > 4) {
                target5TextView.text = currentRiddle.targets[4]
            }
            // Alle Target-Layouts zunächst ausblenden
            for (i in 0 until targetLinearLayout.childCount) {
                targetLinearLayout.getChildAt(i).visibility = View.GONE
            }
            for (i in 0 until linearTextView.childCount) {
                linearTextView.getChildAt(i).visibility = View.GONE
            }
            for (i in 0 until currentRiddle.targets.size) {
                val targetView = targetLinearLayout.getChildAt(i) as FrameLayout
                val targetTextView = linearTextView.getChildAt(i) as TextView

                targetView.visibility = View.VISIBLE
                targetTextView.visibility = View.VISIBLE

                // Text für das Target setzen
                targetTextView.text = currentRiddle.targets[i]

                // Drag-Listener setzen
                targetView.setOnDragListener { v: View, event: DragEvent ->
                    when (event.action) {
                        DragEvent.ACTION_DROP -> {

                            val clipData = event.clipData
                            val option = clipData.getItemAt(0).text.toString()
                            val targetId = v.id // ID des Ziels abrufen
                            val imageResId = if (clipData.itemCount > 1) {
                                clipData.getItemAt(1).text.toString().toIntOrNull()
                            } else {
                                null
                            }
                            userMappings[option] = targetId.toString()

                            // UI aktualisieren: Option im Ziel anzeigen
                            (v as? FrameLayout)?.apply {
                                // LinearLayout für Optionen erstellen, falls noch nicht vorhanden
                                val optionsLayout = if (getTag() != null && getTag() is LinearLayout) {
                                    getTag() as LinearLayout
                                } else {
                                    LinearLayout(context).apply {
                                        orientation = LinearLayout.VERTICAL
                                        layoutParams = FrameLayout.LayoutParams(
                                            FrameLayout.LayoutParams.WRAP_CONTENT,
                                            FrameLayout.LayoutParams.WRAP_CONTENT
                                        ).apply {
                                            gravity = Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM // LinearLayout unten und horizontal zentriert ausrichten
                                        }
                                    }.also {
                                        setTag(it) // LinearLayout mit dem Target verknüpfen
                                        addView(it) // LinearLayout zum FrameLayout hinzufügen
                                    }
                                }

                                // Bild oder Text im Ziel anzeigen:
                                if (imageResId != null) {
                                    optionsLayout.removeAllViews()
                                    // Bild anzeigen, wenn imageResId vorhanden ist:
                                    optionsLayout.addView(ImageView(context).apply {
                                        setImageResource(imageResId)
                                        // Layoutparameter anpassen:
                                        layoutParams = FrameLayout.LayoutParams(
                                            FrameLayout.LayoutParams.WRAP_CONTENT,
                                            FrameLayout.LayoutParams.WRAP_CONTENT,
                                            Gravity.CENTER // Bild in der Mitte des FrameLayout platzieren
                                        )
                                    })
                                } else {
                                    // Text anzeigen, wenn imageResId nicht vorhanden ist:
                                    optionsLayout.addView(TextView(context).apply {
                                        text = option
                                    })
                                }

                                // LinearLayout zum FrameLayout hinzufügen, falls noch nicht vorhanden
                                if (indexOfChild(optionsLayout) == -1) {
                                    addView(optionsLayout)
                                }
                            }
                            // Option aus der Liste entfernen
                            val optionsAdapter = optionsRecyclerView.adapter as OptionsAdapter<*>
                            optionsAdapter.removeOption(option)
                            optionsAdapter.notifyDataSetChanged()
                            true
                        }
                        else -> true
                    }
                }
            }
        } else {
            if (currentRiddle.requiresNumberInput || currentRiddle.requiresTwoNumberInputs || currentRiddle.requiresDateInput || currentRiddle.requiresTimeInput) {
                numberInput.text.clear()
                numberInput2.text.clear()
                dateInput.text.clear()
                // Eingabefelder anzeigen
                numberInput.visibility = View.VISIBLE
                unit1TextView.visibility = View.VISIBLE
                unit1TextView.text = currentRiddle.unit[0] // Erste Einheit anzeigen
                dateInput.visibility = View.GONE
                if (currentRiddle.requiresTwoNumberInputs) {
                    numberInput2.visibility = View.VISIBLE
                    unit2TextView.visibility = View.VISIBLE
                    unit2TextView.text = currentRiddle.unit[1] // Zweite Einheit anzeigen
                }
                if (currentRiddle.requiresDateInput) {
                    unit1TextView.visibility = View.GONE
                    unit2TextView.visibility = View.GONE
                    unitDateTextView.visibility = View.VISIBLE
                    unitDateTextView.text = currentRiddle.unit[0]
                    numberInput.visibility = View.GONE
                    dateInput.visibility = View.VISIBLE
                    dateInput.inputType = InputType.TYPE_DATETIME_VARIATION_DATE
                    dateInput.setHint("Datum eingeben")
                }
                if (currentRiddle.requiresTimeInput) {
                    unit1TextView.visibility = View.GONE
                    unit2TextView.visibility = View.GONE
                    numberInput.visibility = View.GONE
                    dateInput.visibility = View.VISIBLE
                    dateInput.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                    dateInput.setHint("Zeit eingeben 07.00")
                    unitDateTextView.visibility = View.VISIBLE
                    unitDateTextView.text = currentRiddle.unit[0]
                }
                // Einheiten-TextViews ausblenden
                if (currentRiddle.unit.isEmpty()) {
                    unit1TextView.visibility = View.GONE
                    unit2TextView.visibility = View.GONE
                    unitDateTextView.visibility = View.GONE
                }
                // CheckBoxes und RadioButtons ausblenden
                checkBoxes.forEach { it.visibility = View.GONE } // Hide CheckBoxes
                radioGroupAnswers.visibility = View.GONE // Hide RadioGroup
                linearLayoutSpinners.visibility = View.GONE // Hide LinearLayout for Spinners
                linearLayoutRecyclerView.visibility = View.GONE // Hide LinearLayout for RecyclerView
            } else {
                // Eingabefelder ausblenden
                numberInput.visibility = View.GONE // Hide numberInput
                numberInput2.visibility = View.GONE // Hide numberInput2
                dateInput.visibility = View.GONE // Hide dateInput
                unit1TextView.visibility = View.GONE
                unit2TextView.visibility = View.GONE
                unitDateTextView.visibility = View.GONE
                linearLayoutRecyclerView.visibility = View.GONE // Hide LinearLayout for RecyclerView
                // Antworten zufällig sortieren
                val shuffledAnswers = answersshuffle.toMutableList()
                Collections.shuffle(shuffledAnswers)
                // CheckBoxes und RadioButtons anzeigen
                checkBoxes.forEach { it.visibility = View.VISIBLE } // Show CheckBoxes
                radioGroupAnswers.visibility = View.VISIBLE // Show RadioGroup
                linearLayoutSpinners.visibility = View.GONE // Hide LinearLayout for Spinners
                if (currentRiddle.hasMultipleCorrectAnswers) {
                    radioGroupAnswers.visibility = View.GONE // Hide RadioGroup
                    linearLayoutAnswers.visibility = View.VISIBLE // Show LinearLayout for CheckBoxes
                    linearLayoutSpinners.visibility = View.GONE // Hide LinearLayout for Spinners
                    dateInput.visibility = View.GONE // Hide dateInput
                    linearLayoutRecyclerView.visibility = View.GONE // Hide LinearLayout for RecyclerView
                    // Nur CheckBoxes hinzufügen, wenn mehrere Antworten korrekt sein können
                    for (answer in answersshuffle) {
                        val checkBox = CheckBox(this)
                        checkBox.text = answer
                        linearLayoutAnswers.addView(checkBox)
                        checkBoxes.add(checkBox) // Add to the list
                    }
                } else {
                    radioGroupAnswers.visibility = View.VISIBLE // Show RadioGroup
                    linearLayoutAnswers.visibility = View.GONE // Hide LinearLayout for CheckBoxes
                    linearLayoutSpinners.visibility = View.GONE // Hide LinearLayout for Spinners
                    dateInput.visibility = View.GONE // Hide dateInput
                    unit1TextView.visibility = View.GONE
                    unit2TextView.visibility = View.GONE
                    unitDateTextView.visibility = View.GONE
                    linearLayoutRecyclerView.visibility = View.GONE // Hide LinearLayout for RecyclerView
                    // Nur RadioButtons hinzufügen, wenn nur eine Antwort korrekt sein kann
                    for (answer in answersshuffle) {
                        val radioButton = RadioButton(this)
                        radioButton.text = answer
                        radioGroupAnswers.addView(radioButton)
                        radioButtons.add(radioButton) // Add to the list
                    }
                }
            }
        }
        riddleTextView.text = currentRiddle.question
    }

    private fun evaluateAnswer(): Boolean {
        val currentRiddle = riddles[currentRiddleIndex]
        val correctAnswers = currentRiddle.correctAnswers

        val selectedAnswers = when {
            currentRiddle.requiresDateInput -> {
                val dateInput = dateInput.text.toString()
                listOf(dateInput)
            }
            currentRiddle.requiresTimeInput -> {
                val timeInput = dateInput.text.toString()
                listOf(timeInput)
            }
            currentRiddle.requiresNumberInput || currentRiddle.requiresTwoNumberInputs -> {
                val number1 = numberInput.text.toString().toDoubleOrNull() ?: ""
                val number2 = if (currentRiddle.requiresTwoNumberInputs) {
                    numberInput2.text.toString().toDoubleOrNull() ?: ""
                } else {
                    0.0
                }
                if (currentRiddle.requiresNumberInput && !currentRiddle.requiresTwoNumberInputs) {
                    listOf(number1.toString())
                } else {
                    listOf(number1.toString(), number2.toString())
                }
            }
            currentRiddle.requiresOrderedAnswers -> {
                val selectedSpinnerAnswers = linearLayoutSpinners.children
                    .filterIsInstance<Spinner>()
                    .map { it.selectedItem as String } // Direkt als String
                    .toList()
                selectedSpinnerAnswers
            }
            currentRiddle.hasMultipleCorrectAnswers -> {
                getSelectedAnswerCheckBoxes()
            }
            else -> {
                listOf(getSelectedAnswerRadioButtons())
            }
        }
        // isCorrect: true, wenn alle richtigen Antworten ausgewählt wurden und keine falschen
        val isCorrect = if (currentRiddle.hasMultipleCorrectAnswers) {
            correctAnswers.all { selectedAnswers.contains(it) } // Prüfe, ob alle richtigen Antworten in den ausgewählten Antworten enthalten sind
        } else if (currentRiddle.requiresOrderedAnswers) {
            // Ausgewählte Antworten mit den richtigen Antworten vergleichen
            selectedAnswers.size == correctAnswers.size && selectedAnswers.zip(correctAnswers).all { (a, b) -> a == b }
        } else {
            selectedAnswers.size == 1 && correctAnswers.contains(selectedAnswers[0])
        }
        var partiallyCorrect = false
        // Markiere die Antwort-TextViews
        if (currentRiddle.requiresOrderedAnswers) {
            val numCorrectAnswers = selectedAnswers.withIndex().count { (index, answer) ->
                correctAnswers.getOrNull(index) == answer
            }
            val numPossibleAnswers = correctAnswers.size
            val isCorrect = selectedAnswers == correctAnswers
            partiallyCorrect = numCorrectAnswers > 0 && numCorrectAnswers < correctAnswers.size
            if (currentRiddleIndex in 0..29) {
                val textView = answerTextViews[currentRiddleIndex]
                if (isCorrect) {
                    textView.setBackgroundColor(Color.GREEN) // Richtig: Grün
                    totalPoints += 3.33333
                    proceedToNextRiddle()
                } else if (partiallyCorrect){
                    textView.setBackgroundColor(Color.YELLOW) // Teilweise richtig: Gelb
                    totalPoints += 3.33333 * (numCorrectAnswers.toDouble() / numPossibleAnswers)
                    wrongAnswerDialog(correctAnswers, currentRiddle.unit)
                } else {
                    textView.setBackgroundColor(Color.RED) // Falsch: Rot
                    wrongAnswerDialog(correctAnswers, currentRiddle.unit)
                }
            }
        }  else if (currentRiddle.hasMultipleCorrectAnswers) {
            val numCorrectAnswers = selectedAnswers.count { correctAnswers.contains(it) }
            val numPossibleAnswers = correctAnswers.size
            // isCorrect: Alle korrekten Antworten müssen in selectedAnswers enthalten sein
            // und alle selectedAnswers müssen in correctAnswers enthalten sein
            val isCorrect = correctAnswers.all { selectedAnswers.contains(it) } &&
                    selectedAnswers.all { correctAnswers.contains(it) }
            // partiallyCorrect: Mindestens eine korrekte Antwort muss in selectedAnswers enthalten sein
            // und nicht alle selectedAnswers sind korrekt
            partiallyCorrect = numCorrectAnswers > 0 && !isCorrect
            // TextView für das aktuelle Rätsel markieren
            if (currentRiddleIndex in 0..29) {
                val textView = answerTextViews[currentRiddleIndex]
                if (isCorrect) {
                    textView.setBackgroundColor(Color.GREEN) // Richtig: Grün
                    totalPoints += 3.33333
                    proceedToNextRiddle()
                } else if (partiallyCorrect){
                    textView.setBackgroundColor(Color.YELLOW) // Teilweise richtig: Gelb
                    totalPoints += 3.33333 * (numCorrectAnswers.toDouble() / numPossibleAnswers)
                    wrongAnswerDialog(correctAnswers, currentRiddle.unit)
                } else {
                    textView.setBackgroundColor(Color.RED) // Falsch: Rot
                    wrongAnswerDialog(correctAnswers, currentRiddle.unit)
                }
            }
        }  else if (currentRiddle.hasdifferentanswers) {
            //Fragen mit mehreren richtigen Antworten
            val selectedAnswer = radioGroupAnswers.findViewById<RadioButton>(radioGroupAnswers.checkedRadioButtonId)?.text.toString() ?: ""
            // Überprüfen, ob die ausgewählte Antwort korrekt ist
            val isCorrect = currentRiddle.correctAnswers.contains(selectedAnswer)
            // Punkte vergeben, wenn die Antwort korrekt ist
            if (currentRiddleIndex in 0..29) {
                val textView = answerTextViews[currentRiddleIndex]
                if (isCorrect) {
                    textView.setBackgroundColor(Color.GREEN) // Richtig: Grün
                    totalPoints += 3.33333
                    proceedToNextRiddle()
                } else {
                    textView.setBackgroundColor(Color.RED) // Falsch: Rot
                    wrongAnswerDialog(correctAnswers, currentRiddle.unit)
                }
            }
        } else if (currentRiddle.requiresDragAndDrop) {
            var correctAnswers = 0
            val totalAnswers = currentRiddle.correctMappings.size

            for ((option, targetIdString) in userMappings) {
                val correctTargetIdString = currentRiddle.correctMappings[option]

                // targetIdString in Int umwandeln
                val targetId = targetIdString.toInt()

                // Ressourcen-ID des TextView aus dem FrameLayout abrufen
                val targetTextViewId = when (targetId) {
                    R.id.target1 -> R.id.target1TextView
                    R.id.target2 -> R.id.target2TextView
                    R.id.target3 -> R.id.target3TextView
                    R.id.target4 -> R.id.target4TextView
                    else -> 0 // Fehlerfall behandeln
                }
                // Text des Target-TextViews abrufen
                val targetText = if (targetTextViewId != 0) {
                    findViewById<TextView>(targetTextViewId).text.toString()
                } else {
                    "" // Fehlerfall behandeln
                }

                if (targetText == correctTargetIdString) {
                    correctAnswers++
                } else {
                    Log.d("RiddleEvaluation", "Incorrect answer for option: $option")
                }
            }

            if (currentRiddleIndex in 0..29) {
                val textView = answerTextViews[currentRiddleIndex]

                if (correctAnswers == totalAnswers) {
                    textView.setBackgroundColor(Color.GREEN) // Richtig: Grün
                    totalPoints += 3.33333
                    proceedToNextRiddle()
                } else if (correctAnswers == 0) {
                    textView.setBackgroundColor(Color.RED) // Falsch: Rot
                    wrongAnswerDialog(correctMappings = currentRiddle.correctMappings)
                } else {
                    textView.setBackgroundColor(Color.YELLOW) // Teilweise richtig: Gelb
                    val pointsPerCorrectAnswer = 3.33333 / totalAnswers
                    totalPoints += pointsPerCorrectAnswer * correctAnswers
                    wrongAnswerDialog(correctMappings = currentRiddle.correctMappings)
                }
            }
        } else {
            // Fragen mit nur einer richtigen Antwort
            val isCorrect = correctAnswers == selectedAnswers
            // TextView für das aktuelle Rätsel markieren
            if (currentRiddleIndex in 0..29) {
                val textView = answerTextViews[currentRiddleIndex]
                if (isCorrect) {
                    textView.setBackgroundColor(Color.GREEN) // Richtig: Grün
                    totalPoints += 3.33333
                    proceedToNextRiddle()
                } else {
                    wrongAnswerDialog(correctAnswers, currentRiddle.unit)
                    textView.setBackgroundColor(Color.RED) // Falsch: Rot
                }
            }
        }
        return isCorrect
    }

    // Hilfsfunktion, um die ausgewählte Antwort zu erhalten
    private fun getSelectedAnswerRadioButtons(): String {
        val selectedRadioButtonId = radioGroupAnswers.checkedRadioButtonId
        if (selectedRadioButtonId != -1) {
            val selectedRadioButton = findViewById<RadioButton>(selectedRadioButtonId)
            return selectedRadioButton?.text?.toString() ?: "" // Sichere Navigation und Elvis-Operator
        } else {
            return ""
        }
    }

    // Hilfsfunktion, um die ausgewählten Antworten zu erhalten
    private fun getSelectedAnswerCheckBoxes(): List<String> {
        val selectedAnswers = mutableListOf<String>()
        for (checkBox in checkBoxes) {
            if (checkBox.isChecked) {
                selectedAnswers.add(checkBox.text.toString())
            }
        }
        return selectedAnswers
    }

    fun onAnswerDeselected(answer: String, position: Int) {
        // Logik zum Abwählen der Antwort
        selectedAnswersOrder.remove(answer) // Antwort aus der Liste entfernen
    }

    fun onAnswerSelected(answer: String, position: Int) {
        // Logik zum Abwählen der Antwort
        selectedAnswersOrder.add(answer) // Antwort zur Liste hinzufügen
    }

    // Zeige die Gesamtpunktzahl und Zensur an und speichere die Ergebnisse in der Datenbank
    private fun showTotalPointsAndSaveResults() {
        val grade = viewModel.calculateGrade(totalPoints.toInt())
        val dialog = ResultDialog(this, totalPoints, grade)
        dialog.show()
        viewModel.saveResultsToDatabase(riddleMainNumber, totalPoints.toInt(), grade)
    }

    private fun wrongAnswerDialog(correctAnswers: List<String> = emptyList(), currentRiddleUnit: List<String> = emptyList(), correctMappings: Map<String, String> = emptyMap()) {
        proceedToNextRiddle()
        /*if (currentRiddle.requiresDragAndDrop) {
            // Richtige Antworten für Drag-and-Drop-Fragen anzeigen
            val dialog = WrongAnswerDialog(this, correctAnswers, currentRiddleUnit, correctMappings) // correctMappings übergeben
            dialog.show()
            Handler(Looper.getMainLooper()).postDelayed({
                showNextRiddle() // Nächste Frage laden
            },2000) // 2 Sekunden Verzögerung
        } else {
            val dialog = WrongAnswerDialog(this, correctAnswers, currentRiddleUnit)
            dialog.show()
            Handler(Looper.getMainLooper()).postDelayed({
                showNextRiddle() // Nächste Frage laden
            },2000) // 2 Sekunden Verzögerung
        }
         */
    }
    
}